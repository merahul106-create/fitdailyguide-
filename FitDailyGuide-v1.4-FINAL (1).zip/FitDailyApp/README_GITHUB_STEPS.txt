================================================
  FITDAILY GUIDE v1.4 — AAB BUILD GUIDE
  Phone Browser se GitHub pe AAB banao!
================================================

STEP 1: GitHub Account
  → github.com pe jao → Sign Up (free)

STEP 2: New Repository Banao
  → Green "New" button → Repository name: fitdailyguide
  → Public select karo → Create repository

STEP 3: Files Upload Karo
  → "uploading an existing file" link pe click karo
  → Is ZIP ki saari files drag & drop karo
  → Commit changes click karo

STEP 4: Keystore Secret Add Karo
  → Repository → Settings → Secrets → Actions
  → "New repository secret" click karo
  → Name: KEYSTORE_BASE64
  → Value: (neeche wala pura text copy karo)

=== KEYSTORE BASE64 (copy karo) ===
MIIK4gIBAzCCCowGCSqGSIb3DQEHAaCCCn0Eggp5MIIKdTCCBbwGCSqGSIb3DQEHAaCCBa0EggWpMIIFpTCCBaEGCyqGSIb3DQEMCgECoIIFQDCCBTwwZgYJKoZIhvcNAQUNMFkwOAYJKoZIhvcNAQUMMCsEFMN57k1Nse0Ss+vIDwpzecsj12KSAgInEAIBIDAMBggqhkiG9w0CCQUAMB0GCWCGSAFlAwQBKgQQfM5OKTXJxup3XHthURE4fgSCBNDkqyIZmTqi3QJ7eQhbvjQJXWk6Z/uvcJszDBXEvN8QL7xBKB7gifkWeJ/rpfehys8vtzU38f344cSgg8GBR/kEXSr3K6rPoZHtGSYofkn3gx7aAN0z5isW7F0ec7MjbC2iqfIW2kG3sULwzSgNgCsPJXIQFLtF70MCWhkWicQB3eHPDwehJHoTuqr43xhc5laBmV8X9SxQ7UWfa3vDGkjhnNyf1WUMmV8vvn5zg7FvnDyHQQsK7I/b9KEm2IA5tKXTaHns7klmPWEQDN2+Ua1woSK8QajG8B6h64ibFECVOXnyKbVhLAkpWN1YeydR0Qdb4yryimI2aLV3jNGKrk4O8N+8qrwkZOjFxL8I0qtQFsdTU5/ytYPhsnNsq0edHLGHpo2CleKT49YVF7Qs2NoI/CtQ+HxsRVggGO73FYpiYYk8yqNbphxe0tvaR4j4FuNbdwHUKfTbEYvock118NbFBGUVL7J7FL7dJbuh2u1iqBVqOcuWblvAISe/s9WR31i00sVt1bpn5JA4VhI2/BCEuP5MH9QHsVInTim08KuzP0vy7VgoOv2gRyRBMDkX4mc5k8EEYkuAUNBcm1qfYgDhiF4LROkyyRgPzgCDXPg7yuQe7roz53nvjI0D2oImoQModMQ4CkKOMM0EPDL3y28If6Xf2+bnstZlIfwUbq2P7Cqrbd50EDwWtmW3AYYq5CUb2MWizCwnmK1jrgDW4ZTt9pcDqyxNKggbNQ+Hbmim6MZ6WC5F/BZUwIsyufWHN5THhVWUwfj5fNtDtbMx2/KtV5z9yAZyZV5y5zi74V3Pk1ZxqOAFJpNVBqveqyzq38RwFTRu/CnTBgeA6DBY0aE0YhLwe/8DM6B7WcVaJAAqUC82ygGMnlHfvmSaQK5th0UiT7euFqW0UCXH6cWeMCBzKTH1TX3Ab5b9kC4riiI7cgkGBuB0PWLzoNT+jVFvpxVFS1J2sCxxtbutITxJxKNey/uEs+eAR8FsljCYPGs2s013twICRZKDLY2bHdcrn5Z5Q3x+73mrLfLmTCzfMvD/xWuopcqDQknw7S2AbHCUxIWda++w051Bmv6IX2JoBdqGDcO/9IyXvtn83Zm2VjS+dLN9hCpDC38/iJHGBUSHWezCBhWcdd0aA4fbIoqiei5nDWsEtezx59xsJn46kppXBEgm/VOgbcKKWTTIXrTKkJP8ODyNKOAAAQYVRaWJxpeyW626Zmg6cRkZmpewhkmrC0iN2basHEvCgwHGRHFxX6rxicO+izgB4V7FPJ+g73yYzY/HACFTcm3vLmRw15GFMenn1EY66N8oyPYQxVIisOKvJcN32OTuVu86Bf/04WJjizBRq+4sIrfXVze8tnjFVHJHtwEI/8o7cWED9KisipiiiHn+GRpqqg1S9tNMDd+9AvOcGXCNNafsYMPIGUb7P9Hho5c54R+EK9RFB78eOau3RbUwR+chJ6CUX9YK69UL3cM7561ukO2vvBXiVC3XawuacfO8ObsqupfLQ7hSXHPquY3ImYGITm4DS6Pk1ZnlJvdbX0OFdZWEeaoj47TUcq0gBuuyE2QR+XdiAYSeyxWYAvSV/EzXjAmuDbERsulcn7rmit0NWvz9wRnKF/PIF5xI92BU43b6mnCdyys9mzFOMCkGCSqGSIb3DQEJFDEcHhoAZgBpAHQAZABhAGkAbAB5AGcAdQBpAGQAZTAhBgkqhkiG9w0BCRUxFAQSVGltZSAxNzcxOTg3NjU4NTcxMIIEsQYJKoZIhvcNAQcGoIIEojCCBJ4CAQAwggSXBgkqhkiG9w0BBwEwZgYJKoZIhvcNAQUNMFkwOAYJKoZIhvcNAQUMMCsEFBsiCUUuaGG0MCd8nIPm5Nlw/vugAgInEAIBIDAMBggqhkiG9w0CCQUAMB0GCWCGSAFlAwQBKgQQLOwM3gsxH9OGBmqzBCNXJ4CCBCCv/g+BQgIqYYTtB2NSPqBJVGTfvogtTrBVbcu88KlPRrYylYN+wgv9TWgWqch8KSlKQCTLBr+we4zWGkfqPcSr07vct7c8bBvPbg6qz8UzYi45aoeaBJ9iTsIEyI8gqKoDbp44B92RRA2eIMILJhFEwNDEmue9kxUVW9I0LNuZPxIqtJKMwYymHI2lbxXlLmidpKNtysUgp+5n7FoMjjfkyKuGqvrCKGlm3xIr3xeWBQiFNLFK46JKUjSw51JOxk/0dUW8tHM2+Tr3w+PIAiZyeaqMz5DhvOI8AeuDRJ+gKI/xVv+5JCo0ZWwh3JbyzxKAnr8xsGnMsLVE9yGku4LET4vj7FiZwBEpiNaSMRF+TpGSPedUVERSh7JSTutsFaMFSTc2koLq5pgfAe6NljnBBe+NgZk3ErzHUao5OXoqG4P07C+QJPEZGH3Avf3JNI9+N8f9EGXSM2DlqyniUuQcPwJyxn+01846a8GgT0IgJPykxLH2JpJNU7x9qsCIaI5GnIRbFwr5tOQSH1VtCLeX19g/bZqVUb6XBMpFyzaiwNBxPdJbpLPgsFfdh0rz+pOk+TNrq8SxxKD35YQLOiwjg7z7SfxPe8UG5e0nh3UZpa5ggOM1tBaMqJ4xm4OtGCVhtNKmK1F3gDmx9P2N9YcB0QEQE+g92EnYBvMMEPsBpBrc0QrZ1mHEpzP4KqAxc25EBlRtRLT3B+xUDw/pppQENrc1WMWXurJ5uEfgqwQj8tEYBdN15uUqxHrHkXBbXOht9S3kFMB/A4w+CXI/c2OdzvLOOaB6ZfFZFQDvXE8AekChgw+fUAPT0c22E1ujZpZdvB+5CHXgiHIF26h/KrJtE/UP6E785uZMjrE5cqwsjtFmFC0igs8dAQbfd1wQ9/XiUFSIqonaJBRNWNPfdQuWU3CgG2HrimVIL71/99bp7vYiJlnpA+LKaIDdhHvbKZNalGONVShT6tV0n1yt7TdFaQNfWyORu0miszKTYAH8HljMvwSbMqaz8hhkHsKwvwvCO9BgvUQW7N+fOHtpaO7CVMN0XQZAzOxr9kTcZIqOBzk0UkYDDMiXYi5r2Xw1H97+aj+PlH0deBWlzTEakSUfYfnZ/hLkzmaCFqdwHDOa7k/0L9MWb5V6F4DGIwzCza+Mfon6nL7inZCLpXFwvhdiydtZGP/bbetCQkape6HRiW/5oTcc8tlarfsY1wjuTj8iSMNbsRfX9VLVkEvMgH1w10AVmxk4FezHDzZ8MnF4mzLJ1vnHBRk2X3U7EtUN9KWtQuFNP4euOHXd6COC+HySRPFtmbGC7fLjEmGH6O5nKKl8lGzTZIXpqxEmWo6NXnsUFod4hhcCXxMUKOUQAHbuSmnQpoZxfn3jtGq+vDBS3N9T1p6Rv6stozkQcaQILPAwTTAxMA0GCWCGSAFlAwQCAQUABCD5BuxzGkwL0/+IkLA5xUnVA1ycIWRuNqVIVdR82UokDwQU6buxmyUSTl3u88AcMUshaU6g57oCAicQ
=== END ===

STEP 5: AAB Build Karo
  → Repository → Actions tab
  → "Build FitDaily AAB" workflow
  → "Run workflow" button dabao
  → 5-10 min mein build hoga!

STEP 6: AAB Download Karo
  → Actions → Latest run → Artifacts
  → "FitDaily-Guide-v1.4-RELEASE" download karo
  → ZIP ke andar .aab file hogi

STEP 7: Play Console Upload
  → play.google.com/console
  → App → Production → Create release
  → AAB file upload karo → Publish!

KEYSTORE DETAILS:
  Password : IUw7iplgAl7r
  Alias    : fitdailyguide
  Valid    : Until 2051

© My Company · Telangana, India · v1.4 · Build 104
================================================

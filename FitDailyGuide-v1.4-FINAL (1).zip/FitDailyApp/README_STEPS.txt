================================================
  FITDAILY GUIDE v1.2 — ANDROID PROJECT
  by My Company | Telangana, India
================================================

FILES IN THIS ZIP:
  fitdailyguide.jks         ← Keystore file (signing key)
  app/src/main/assets/      ← index.html (your app)
  app/build.gradle          ← has keystore config built-in

KEYSTORE DETAILS (SAVE THIS!):
  File:          fitdailyguide.jks
  Store Password: IUw7iplgAl7r
  Key Alias:     fitdailyguide
  Key Password:  IUw7iplgAl7r
  Valid Until:   2051

HOW TO BUILD AAB FOR PLAY STORE:
  1. Android Studio mein open karo ye folder
  2. Build → Generate Signed Bundle → Android App Bundle
  3. "Choose existing keystore" → fitdailyguide.jks select karo
  4. Password: IUw7iplgAl7r
  5. Alias: fitdailyguide
  6. Next → Release → Finish
  7. AAB file milegi → Play Store upload!

NOTE: Keystore already build.gradle mein set hai
      debug aur release dono same key se sign hote hain
      Key issue NAHI ayega!

© My Company | Telangana, India | Build 100
================================================
